﻿using System;

namespace exercise_02
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Your code here:
        }
    }
}
